# mindfagg v41 - modulare Architektur

## v41: Pretty Code und API-basierte GitHub-Vorschläge

- `script/pretty-code.js`: Offline-Formatter für HTML/JS/CSS/XML/SVG, ohne zusätzliche Drittanbieterbibliotheken. Benutzt den bereits gebündelten Acorn-Parser für die JS-Strukturprüfung und (im Browser) `DOMParser` für XML/SVG-Wohlgeformtheit. Die Formatierung arbeitet auf `codeFoldFull(source)`, nicht auf den Fold-Platzhaltern. Bei fehlgeschlagener Prüfung ändert sie keinerlei Dokumentdaten.
- `script/find-replace.js`: Ergänzt in der bestehenden Editor-Toolbar den Pretty-Code-Button, `script/editor.js` registriert `scriptPrettyMount(doc)`. Tatsächliche Änderungen werden an `scriptFindApplyChange()` übergeben; der normale Editor-`input`-Handler sorgt für Syntaxdiagnose, Persistenz, Undo/Redo und Find-Highlights. `script/find-replace.css` blendet den Button bei nicht unterstützten Dateiformaten aus.
- `workspace/github.js`: `githubListAccountRepositories()` paginiert `GET /user/repos` mit dem entschlüsselten In-Memory-Token. `openGithubDialog()` verwaltet eine dialoglokale, filterbare Trefferliste und zeigt API-Fehler an. Es gibt keinen neuen persistenten Cache und keine Änderung an GitHub-Verbindungen, Sync-Baselines, Token-AES-GCM oder Projekt-ZIPs. Ein veralteter Request kann keinen geschlossenen/neuen Dialog überschreiben.
- `workspace/github.css`: Dropdown, Scrollbereich, private/öffentliche Kennzeichnung und Tastaturfokus.
- `index.html`, `module-manifest.json`, `sw.js`: Bindet `script/pretty-code.js` nach `script/find-replace.js`, vor `script/editor.js` ein und nimmt es in den Offline-Precache auf. SW-Version `mindfagg-v41`; keine externen Skripte/CDNs, kein Build-Schritt.

**Hinweis zu Pretty Code:** Die konservative Strukturformatierung ist keine vollständige Prettier-Implementierung. JavaScript-Fehler und AST-Abweichungen verhindern eine Änderung. XML/SVG bleibt bei fehlerhafter Struktur unverändert. Bei HTML mit Inline-/Mischtext wird Inhalt nicht umgebrochen, um Textabstände zu erhalten.

---

# Versionshistorie: v40


## v40: Suchen und Ersetzen, GitHub-Vorschlag, mobile Toolbar

- `script/find-replace.js`: Literal-Suchlogik im vollständigen `codeFoldFull()`-Text, Ergebnisverwaltung, Fallunterscheidung, Markierungen (escaped Overlay), Navigation sowie Einzel-/Alle-Ersetzen. `scriptFindApplyChange()` schreibt den kanonischen Quelltext in den vorhandenen Code-Folding-Zustand, löst genau ein Editor-`input`-Event aus und verwendet damit die bestehende History/Autosave/Diagnose-Pipeline. Es gibt **keine zweite persistente Datenquelle**.
- `script/find-replace.css`: Werkzeugleiste und auf-/zuklappbares Suchpanel. Auf Mobilgeräten ordnet `mobile-script-active` die Leiste am unteren Rand des über `visualViewport` angepassten Editors ein, entsprechend der Markdown-Bedienung.
- `script/editor.js`: Fügt die neue Toolbar/Overlay-Ebene hinzu und synchronisiert Suche/Markierungen mit dem normalen Syntax-Layer, minimap und den Source-Events. `ui/router.js` gibt den temporären mobilen Viewport-Zustand beim Wechsel der Ansicht frei.
- `workspace/github.js` / `.css`: Ergänzen nur den UI-Vorschlag für `githubCredentialAccount + '/'`; das bestehenden GitHub-Verbindungs- und Synchronisationsschema wird nicht geändert.
- `ui/settings.js`: Setzt den fehlenden `codeFolding`-Wert und den Reset auf `false`. Ein gespeichertes `true` bleibt absichtlich erhalten.
- `index.html`, `module-manifest.json`, `sw.js`: Registrieren die zwei neuen Script-Editor-Assets und aktivieren `mindfagg-v40` als Offline-Cache. Alle vorherigen Dateien aus v39 bleiben erforderlich.

## v39: verlustfreie Codefaltung

- **`core/code-folding.js`:** Scannt HTML/XML/SVG-Tags, JavaScript- und CSS-Blöcke sowie Markdown-Abschnitte und erzeugt ausschließlich für die Anzeige eine Textprojektion mit Fold-Platzhaltern. `doc.content` bleibt die einzige persistente Quelle. `codeFoldUpdateAfterInput()` führt Eingaben auf sichtbaren Quellzeilen auf den vollständigen Text zurück; vor Eingriffen in Platzhalter, Toolbar-Aktionen oder Diagnose-Navigation werden die betroffenen Bereiche aufgeklappt.
- **`css/code-folding.css`:** Positioniert bedienbare Fold-Pfeile im Quelltext-Gutter und erhält ihre Ausrichtung bei Wordwrap, Scrollen, mobilen Viewports und ausgeblendeten Zeilennummern.
- **Editor-Integration:** `markdown/editor.js`/`script/editor.js` initialisieren pro Dokument einen sitzungsgebundenen Faltzustand; `markdown/highlight.js`, `markdown/controls.js`, `markdown/completions.js` und `script/functions.js` respektieren Original-/Anzeigepositionen. `flushSource()` schreibt stets den unveränderten vollständigen Inhalt.
- **Einstellungen:** `ui/settings.js` erweitert den bestehenden `mfEditorPreferencesV28`-Schlüssel um `codeFolding: true`. Keine Datenbankmigration.
- **Ressourcen:** `index.html`, `module-manifest.json` und `sw.js` registrieren beide neuen Dateien für die Offline-PWA und heben den Cache auf `mindfagg-v39`. Alle übrigen Quelldateien aus v38 bleiben erforderlich; das v39-Änderungsarchiv ist ausdrücklich **kein** vollständiger Anwendungsordner.

## Ziel und Umfang

v32 baut auf der v30-Strukturrefaktorierung auf. Der neue Import-/Export-Bereich erweitert die Dateiverwaltung; Datenbank (`mindfagg-db`), Datenformate, Projekt-ZIP-Import/-Export, Editor-Bedienung, Mindmap und die isolierte HTML-Vorschau bleiben erhalten. Die 180 KB große `index.html` aus v29 wurde auf ein knapp 7 KB großes HTML-Grundgerüst reduziert. Das ursprüngliche Inline-JavaScript wurde anhand seiner AST-Deklarationsgrenzen in nach Verantwortlichkeiten benannte Dateien aufgeteilt. CSS-Regeln stehen in getrennten Stylesheets; ihre ursprüngliche Reihenfolge wurde beibehalten.

**Kein Framework, keine Laufzeit-Abhängigkeit zu einem CDN und kein Build-Schritt erforderlich.** `index.html` bindet alle Quelldateien unmittelbar ein.

## Verzeichnisstruktur

```text
mindfagg-v30/
├── index.html                HTML-Grundgerüst und Ressourcenreferenzen
├── module-manifest.json     Registrierte lokale Scripts, Styles und Cache-Assets
├── manifest.webmanifest     PWA-Metadaten
├── sw.js                    Offline-Cache + read-only VFS-Service-Worker
├── core/
│   ├── state.js             Gemeinsamer Zustand, Status, Akzentfarben, Menü
│   ├── database.js          IndexedDB-Helfer
│   ├── history.js           Undo-/Redo-Snapshots und History-Zustand
│   ├── persistence.js       Speichern, History-Operationen, Save-Indikator
│   ├── documents.js         Dokument-/Projektdaten, Auswahl und Initialisierung
│   └── service-worker.js    Registrierung des Service Workers
├── markdown/
│   ├── parser.js            Scanner, Parser, Datumsauswertung und Baumzugriff
│   ├── nodes.js             Knotentypen und Titel-Darstellung
│   ├── highlight.js         Markdown-Markup, Zeilennummern und Minimap
│   ├── controls.js          Inline-Steuerungen im Markdown-Text
│   ├── completions.js       Autocomplete und Wiki-Links
│   ├── commands.js          Listen, Checkboxen, Status und Einrückung
│   ├── editor.js            Editor-DOM, Ereignisse, Autosave und Mobile-Viewport
│   └── *.css                Editoreigene Styles in ursprünglicher CSS-Reihenfolge
├── mindmap/
│   ├── state-layout.js      Fold, Zoom, Hierarchielayout, Knoten-Toolbar
│   ├── inline-edit.js       Direkte Titelbearbeitung
│   ├── operations.js        Copy/Paste, Knoten verschieben, erstellen, löschen
│   ├── interactions.js      Pointer-Gesten, Drag-and-drop, Rendering
│   └── *.css                Mindmap-CSS
├── workspace/
│   ├── files.js             Workspace-Baum, Dateitypen, ZIP und Dateioperationen
│   ├── files.css             Styles der Dateiliste und Ordneransicht
│   ├── io.js                Menüs, Datei- und ZIP-Import, Download/Teilen, Zwischenablage, Drag-and-drop, Batch-History
│   ├── github.js            Drei-Wege-GitHub-Sync, PAT-Persistenz, Konfliktauflösung
│   ├── github.css           Sync-Zustand und Dialogdarstellung
│   └── io.css
├── script/
│   ├── find-replace.js       Suchen und Ersetzen über vollständigen Quelltext
│   ├── find-replace.css      Toolbar, Floating Panel, Mobil-Viewport
│   ├── editor.js            Scripteditor, Syntaxhighlighting, Minimap
│   ├── functions.js         JavaScript-Funktions- und Event-Handler-Übersicht
│   └── editor.css
├── preview/
│   ├── html-preview.js      Isolierte HTML-Vorschau mit lokalem Ressourcen-Broker
│   └── html-preview.css
├── views/
│   ├── kanban.js            Kanban und Tierlist
│   ├── kanban.css
│   ├── calendar.js          Kalender
│   └── calendar.css
├── ui/
│   ├── router.js            Zentrales render() und Benachrichtigungen
│   ├── bindings.js          App-Buttons, globale Shortcuts und Start
│   ├── settings.js          Globale Editor-Einstellungen und GitHub-Zugangsdaten
│   ├── settings.css
│   ├── dialogs.js           Projekt-/Dokument-/Knotendialoge
│   ├── responsive-shell.css
│   ├── node-dialogs.css
│   ├── project-components.css
│   └── theme.css
├── css/
│   └── foundation.css       Grundlayout, UI-Basisklassen und Basisthema
├── vendor/
│   ├── prism.min.js         PrismJS-Bundle (MIT)
│   └── acorn.js             Acorn-Parser (MIT)
├── icons/                   PWA-Icons
├── tests/
│   ├── check-structure.mjs  Prüfung von Pfaden, Script-Syntax und Cache-Manifest
│   ├── github-sync.mjs      Drei-Wege-Sync- und Git-Blob-Tests
│   ├── github-credentials.mjs AES-GCM- und Token-Persistenztests
│   └── github-browser.py    Isolierter Browser-Integrationstest
├── ARCHITECTURE.md
├── TESTS.md
├── THIRD_PARTY_LICENSES.md
└── ACORN_LICENSE.txt
```

## Laufzeit und Modulgrenzen

**Wichtig: v30 verwendet weiterhin klassische Browser-Scripts, noch keine nativen ES-Module.** Das ist eine bewusste Kompatibilitätsentscheidung: Der Bestand verwendet gemeinsam sichtbare `let`-/`const`-Deklarationen und Funktionsnamen über Dateigrenzen hinweg. Ein sofortiger Wechsel zu `type="module"` würde diese Bindungen isolieren und insbesondere zustandsverändernde Zugriffe (beispielsweise auf `docs`, `projectId` oder `view`) brechen. Die Dateien sind funktional getrennt, behalten für v34 aber ihre gemeinsamen globalen Bindungen. Echte `import`-/`export`-Schnittstellen sollten in einem *separaten* Refactoring mit zentraler State-API eingeführt werden.

**Script-Reihenfolge:**

1. `core/` (State, IndexedDB, History, Persistenz, Dokumente)
2. `markdown/parser.js`, `ui/router.js`, `markdown/nodes.js`
3. `mindmap/` (Layout → Inline-Edit → Operationen → Interaktionen)
4. `markdown/` (Highlight → Controls → Completions → Commands → Editor)
5. `workspace/files.js`, `preview/html-preview.js`, `ui/settings.js`
6. `vendor/prism.min.js`, `vendor/acorn.js`
7. `script/functions.js`, `script/validators.js`, `script/find-replace.js`, `script/editor.js`, `views/kanban.js`, `views/calendar.js`, `ui/dialogs.js`
8. `workspace/io.js`, danach `workspace/github.js` (GitHub-API-Client und Dialog)
9. `ui/bindings.js` (registriert Ereignisse und startet `init()`), danach `core/service-worker.js`

Alle Script-Referenzen stehen in dieser Reihenfolge in `index.html` und `module-manifest.json`. Bei Änderungen an gemeinsam genutzten Variablen, Funktionsnamen oder der Script-Reihenfolge **müssen abhängige Module mitgeprüft** werden. Ohne weitere Umstellung sollte man keine `async`-/`defer`-Attribute oder `type="module"` hinzufügen.

**CSS-Reihenfolge:** Bei der ersten Auslagerung wurde die historische CSS-Kaskade bewusst *nicht* neu sortiert. Die aufgeteilten CSS-Fragmente in `index.html` liegen in genau derselben Reihenfolge wie das bisherige Inline-CSS; danach folgen die schon zuvor externen Stylesheets. Die Dateien sind nach den bestehenden Funktionsbereichen benannt, können teilweise ältere, bereichsübergreifende Overrides enthalten. Ein Zusammenführen nach Selektoren wäre eine separate visuelle Änderung und sollte mit Screenshots getestet werden.

## Datenflüsse und Verantwortung

- **`core/`** besitzt die gemeinsame Datenhaltung, History und Speichertransaktionen. Workspace-Dateien und Ansichten dürfen nicht parallel eine eigene persistente Datenquelle führen.
- **`workspace/files.js`** behandelt Projektpfade, Bild-/Binärdaten, Ordner und ZIP-Archive. Die Pfade bleiben bei Export/Import erhalten.
- **`markdown/parser.js`** ist die Quelle für Markdown-Scan und Baumstruktur; alle Knotenansichten verwenden diesen Parser.
- **`markdown/editor.js`** und **`script/editor.js`** verwenden die gemeinsamen Editor-Einstellungen und die History-/Autosave-Funktionen.
- **`mindmap/operations.js`** bearbeitet weiterhin Markdown, nicht eine zweite Baum-Persistenz.
- **`preview/html-preview.js`** lässt Workspace-Webseiten in einem `iframe` mit `sandbox="allow-scripts"` laufen. Der Parent stellt lokale Ressourcen ausschließlich lesend bereit; die Vorschau erhält keinen direkten Zugriff auf App-State oder IndexedDB.
- **`sw.js`** bedient einerseits das App-Offline-Caching, andererseits read-only VFS-URLs. Die bestehenden CSP-/Sandbox-Header, MIME-Typen und Range-Responses bleiben erhalten.
- **`ui/router.js`** entscheidet über Markdown, Mindmap, Kanban, Kalender, Script-Ansicht und Vorschauen. **`ui/bindings.js`** startet die Anwendung erst nach dem Laden aller Funktionen.

## PWA, Versionswechsel und Bestandsdaten

- Service-Worker-Cache: `mindfagg-v34`; der Aktivierungsschritt entfernt alte Versionen.
- Der komplette Cache-Assetkatalog steht in `module-manifest.json` und `sw.js`. Bei neuen Dateien **beide** Einträge aktualisieren.
- IndexedDB `mindfagg-db` wird von Version 1 auf Version 2 aktualisiert. Die vorhandenen Stores `projects` und `docs` bleiben erhalten, neu ist `settings` für die lokal verschlüsselten App-GitHub-Zugangsdaten.
- Bereits installierte v29/v30-PWAs brauchen einen normalen Reload nach dem Update, damit der neue Service Worker alle verschobenen Ressourcen installiert.
- ZIP-Archive bleiben mit v29/v30 kompatibel. Der Export trägt Metadaten mit `version: 31`.
- Start: `index.html` öffnen. `file://`-Sicherheitsbeschränkungen hängen vom Browser ab; für PWA/Service Worker einen lokalen Webserver bzw. HTTPS verwenden.

## Entwicklung und Validierung

Aus dem App-Verzeichnis: `node tests/check-structure.mjs`. Der Test benötigt nur Node.js; für die App selbst ist Node nicht erforderlich. Er prüft Verweise, Lade-Reihenfolge, lokale Assets, `sw.js` und die Syntax aller eingebundenen JavaScript-Dateien. Ergänzend `TESTS.md` für manuelle und Browser-Regressionsprüfungen nutzen. Bei umfangreicheren Änderungen zunächst nur die Dateien des betroffenen Funktionsbereichs plus `core/`/`ui/router.js` bereitstellen.

## Neue Dateiaktionen (v32)

- `index.html` enthält bei **DATEIEN** die beiden Schaltflächen `#addDocument` und `#workspaceMore` sowie versteckte Datei- und ZIP-Inputs. Der frühere Sidebar-Footer mit den beiden großen ZIP-Buttons entfällt.
- `workspace/io.js` wird **nach `ui/dialogs.js` und vor `ui/bindings.js`** geladen. `ui/bindings.js` ruft `wireWorkspaceIO()` auf, das Menüs, File-Inputs, Tastatur-Paste und Drop-Zonen verbindet.
- Datei- und ZIP-Importe validieren Pfade über `workspaceValidPath()`. Mehrfachdateien werden vor der Transaktion vorbereitet, Konflikte nach Wahl aufgelöst und dann atomar in `docs` und `projects.folders` gespeichert.
- `workspaceCommitBatch()` erstellt für die Importaktion ein `workspace-batch`-History-Element auf dem vorhandenen strukturellen `deletionHistory`-Stack. Es bewahrt vorherige und neue Datei-Records einschließlich Binärbytes und Ordnerliste auf. `core/persistence.js` routet Undo/Redo-Einträge dieses Typs an `applyWorkspaceBatchHistory()`.
- Im bestehenden Projekt sind auch Ordnererstellung, -umbenennung, -löschung und Dateierstellung damit rückgängig zu machen. Die Historie bleibt wie bisher sitzungsgebunden; IndexedDB speichert den aktuellen Workspace, **nicht** die Undo-Historie.
- Neuer ZIP-Import als neues Projekt nutzt die bestehende atomare `commitImportedWorkspace()`-Transaktion. Der Import in einen ausgewählten Ordner verwendet `workspaceCommitBatch()`. Bilder/Binärformate bleiben bytegetreu, unveränderte Textdateien behalten ihre ursprünglichen Rohbytes.
- Die Web Share API (`navigator.share` / `navigator.canShare`) öffnet bei Unterstützung die native Dateifreigabe. Andernfalls wird dieselbe ZIP-Datei heruntergeladen. Ein abgebrochener Teilen-Dialog löst keinen automatischen Download aus.
- Für die Zwischenablage wird zuerst die asynchrone Browser-API verwendet; bei fehlender Freigabe wird ein Paste-Feld angeboten, das über ein echtes `paste`-Ereignis auch Bilddaten übernehmen kann.

**Hinweis:** Native Teilen-Dialoge und `navigator.clipboard.read()` erfordern je nach Browser eine sichere Umgebung und explizite Benutzerinteraktion. Die Dropdowns dienen nur der UI; sie erweitern nicht die Berechtigungen von HTML-Vorschauen oder dem virtuellen Dateisystem.


## Ergänzungen in v32

- `workspace/files.js`: Audio-MIME-Zuordnung, Import-Klassifizierung als `audio`, Erkennung bisheriger `binary`-Audiodateien und `renderAudioView()` mit nativen `<audio controls>`. Ursprüngliche Binärbytes bleiben für den Export erhalten.
- `workspace/files.css`: Responsive Audioplayer-Oberfläche.
- `preview/html-preview.js`: Instrumentierung von `console.log/info/warn/error/debug` sowie `error`/`unhandledrejection` innerhalb des opaque-origin Frames. Das Elternfenster nimmt ausschließlich Nachrichten des aktuellen Frames mit korrektem Sitzungstoken an, begrenzt Text auf 8000 Zeichen und hält höchstens 100 Einträge.
- `preview/html-preview.css`: Konsole als zuschaltbarer Drawer, Kopieraktion je Eintrag, Vollbild über Fullscreen API mit CSS-Fallback.
- `sw.js`: Offline-Cache auf `mindfagg-v34` angehoben. Das IndexedDB-Schema erhält den zusätzlichen Store `settings` (Version 2).

## GitHub-Synchronisation (v34)

- **Appweite Authentifizierung:** `ui/settings.js` hält den Zugangsdaten-Dialog unter App-Einstellungen. `githubSaveCredentials()` prüft den PAT über `GET /user` und verschlüsselt ihn mit AES-GCM. Der nicht exportierbare `CryptoKey` und `{iv,cipher,account,savedAt}` stehen im neuen `settings`-Store der IndexedDB. `githubRestoreCredentials()` lädt ihn während `init()`, `githubRemoveCredentials()` entfernt den Credential-Eintrag. Der Klartext ist nur während der Laufzeit im App-Kontext. Diese Verschlüsselung bietet keinen XSS-/Profil-Übernahmeschutz.
- **Projektspezifische Zuordnung:** `project.github = {owner,repo,branch,baseline,lastCommit,lastSyncedAt}` liegt im Store `projects`. `baseline` enthält Git-Blob-SHA-1-Hashes und Dateimodi pro Pfad. Verbindung und Branch lassen sich in **Projekteinstellungen** ändern, unabhängig vom appweiten Token; `main` ist Standard. Ein Wechsel zu einem anderen Repository leert die bisherige Baseline, damit keine vermeintlich bekannten Dateien überschrieben werden.
- **Ein-Klick-Sync:** `#githubSync` steht in der Sidebar unter DATEIEN; `ui/bindings.js` ruft `githubSyncClicked()` auf. Der Button zeigt per `githubUpdateIndicator()` den Zustand. `githubProjectActivated()` prüft bei Projektwechsel den Remote-Snapshot; `githubScheduleLocalStatus()` reagiert auf lokale Saves. Transfers laufen ausschließlich nach Klick, nicht durch Hintergrund-Polling.
- **Drei-Wege-Diff:** `githubFetchSnapshot()` lädt Ref, Git-Commit und rekursiven Tree; `githubLocalFiles()` erzeugt zu jeder Workspace-Datei den echten Git-Blob-Hash. `githubClassify(local,remote,tracked)` unterscheidet lokale Uploads, Remote-Downloads, bereits identische Dateien, Konflikte und unzulässige Pfade. Neu/Änderung/Löschung werden auf beiden Seiten berücksichtigt; unbekannte Remote-Dateien sind keine Löschungen.
- **Konflikte:** `githubOpenConflictDialog()` zeigt alle Konflikte gesammelt, `githubConflictCard()` stellt Größe und Änderungszeit für beide Varianten dar. Remote-Zeit stammt – soweit verfügbar – vom letzten Commit der Datei via `GET /commits?sha=...&path=...`; Git-Objekte speichern kein einzelnes Änderungsdatum. `githubResolveAndSync()` prüft Signatur von Remote-HEAD, lokalen Dateien und Baseline erneut. Lokal oder GitHub kann einzeln gewählt werden; nicht entschiedene Konflikte bleiben offen.
- **Transaktionen:** `githubExecutePlan()` lädt und verifiziert alle Remote-Blobs **vor jeder Änderung**. Danach erfolgen ein weiterer Lokaldaten- und Ref-Vergleich sowie bei Bedarf ein Upload aller Änderungen in einem Commit (`githubCommitUploads()`, `force:false`). Nach dem Commit wird der lokale Zustand nochmals geprüft, bevor `workspaceCommitChanges()` heruntergeladene oder entfernte Dateien in **einer IndexedDB-Transaktion und einem Undo-Schritt** umsetzt. Ein Fehler oder geänderter Stand verhindert das ungefragte Überschreiben.
- **Sicherheit & Ressourcen:** GitHub-Zugriff ausschließlich auf `https://api.github.com`, Authorization-Header, keine Weitergabe an Drittanbieter. Maximal 20 MiB pro Datei, 80 MiB je Upload/Download und 750 Downloads je Abgleich. Symlinks, Submodule, Git LFS und leere Ordner sind ausgenommen. Nicht exportierbare Dateisystem-/Browserartefakte können nicht in Git abgebildet werden.
- **Tests:** `node tests/check-structure.mjs`, `node tests/github-sync.mjs`, `node tests/github-credentials.mjs` und `python3 tests/github-browser.py`. Der Browser-Test verwendet in dieser Umgebung temporär inline geladene Ressourcen sowie simulierte GitHub- und IndexedDB-Aktionen; die Tests enthalten keinen realen GitHub-Upload oder Browser-Neustart mit echter IndexedDB.

## v36: Offline-Validatoren und neue UI-Verbindungen

- `script/validators.js` wird **nach** `vendor/acorn.js` und **vor** `script/editor.js` geladen. Das Modul stellt `validateScriptContent()` (ausführbare Syntaxprüfung ohne Codeausführung), `parseJavascriptCode()`, `validateCssCode()`, `validateHtmlCode()` und `detectClipboardCodeLanguage()` bereit. Der Clipboard-Import in `workspace/io.js` verwendet dieselben Validatoren wie der Editor.
- `script/editor.js` positioniert Fehler anhand von `{offset,line,column,length}` im Gutter und in einer separaten, nicht-interaktiven Overlay-Ebene über der Prism-Syntax. Die klickbaren Diagnosemeldungen fokussieren den Original-Textarea-Cursor. Die Prüfung nach einer Eingabe wird um 180 ms verzögert, die Speicherung bleibt getrennt davon.
- `workspace/github.js` erzeugt Repo-Links nur aus den validierten `owner/repo`-Bestandteilen, nicht direkt aus Benutzereingaben. Appweite GitHub-Zugangsdaten bleiben in `ui/settings.js` und IndexedDB (`settings`-Store); der Wechsel der Input-Art verändert weder Kryptografie noch Synchronisationslogik.
- `mindmap/state-layout.js` verwendet einen von der Elterntiefe abhängigen Abstand, ohne das Node-Datenformat, die Pfade oder Drag-and-drop-Operationen zu verändern.
- `sw.js` und `module-manifest.json` führen `script/validators.js` als Offline-Ressource und verwenden v36 als Cache-Version. Keine Datenbankmigration erforderlich.

## v37: Mindmap-Abstände und einheitlicher Knotendialog

- `mindmap/state-layout.js`: `positionMapRows()` bestimmt die vertikalen Abstände über `siblingGap(depth)`. Bei `depth===0` 64 px (24 px mehr Abstand zwischen den Kontext-Teilbäumen); bei `depth===1` 30 px, `depth===2` 18 px, sonst 12 px (jeweils doppelt gegenüber v36). Messung und Positionierung verwenden denselben Wert, damit die Verbindungsgeometrie stimmig bleibt.
- `ui/dialogs.js`: `editNode(path)` unterscheidet nicht mehr nach `view==='kanban'`, sondern stellt stets `nodeStatus` bereit und übernimmt den Wert beim Speichern über `lineEdit()`. Kanban-Karten können so auch ohne Drag & Drop in eine andere Statusspalte wechseln.
- Service Worker und Manifest erhalten v37 als Cache-/Paketversion.

## v38: Optionale Freigabe des Browser-Speichers für HTML-Vorschauen

- `ui/settings.js`: `appEditorSettings.previewStorageAccess=false` wird wie die übrigen appweiten Präferenzen über `mfEditorPreferencesV28` lokal gespeichert. Es gibt eine eigene App-Einstellungen-Sektion mit Schalter und deutlicher Sicherheitswarnung. Der Reset-Button für **Editor**-Einstellungen verändert die Vorschau-Berechtigung nicht.
- `preview/html-preview.js`: Das iframe erhält standardmäßig nur `allow-scripts`; erst nach Opt-in kommt `allow-same-origin` hinzu. `htmlPreviewStorageBlockedError()` erkennt Sandboxing-Fehlermeldungen für Storage-APIs. `htmlPreviewLog()` öffnet die Konsole automatisch, `htmlPreviewRenderLogs()` zeigt den Freigabe-Button, `htmlPreviewGrantStorage()` speichert die Einstellung und ruft `htmlPreviewLoad()` für einen sofortigen Neustart auf.
- `preview/html-preview.css` und `ui/settings.css`: Sicherheitskennzeichnung und Warntext (Desktop/Mobil).
- **Sicherheitsgrenze:** `srcdoc` plus `allow-scripts allow-same-origin` ist für nicht vertrauenswürdiges HTML **keine isolierte Sandbox**. Das Vorschau-Dokument kann den Ursprung der App und das Parent-DOM erreichen, darunter potenziell die unverschlüsselt genutzten GitHub-Zugangsdaten zur Laufzeit. Die Freigabe bleibt deshalb opt-in (Standard aus); sie gilt global für alle Projekte. Es wird **nicht** behauptet, eine separate Storage-Partition bereitzustellen. Beim Deaktivieren ist nur der künftig geladene Frame wieder isoliert; etwaige zuvor gelesene Daten können nicht zurückgerufen werden.
- **Browsergrenzen:** Die Sandbox-Umschaltung ist automatisiert getestet. Die Testumgebung blockiert HTTP-/file-Navigation und erlaubt daher keinen aussagekräftigen End-to-End-Test von nativem `localStorage`/`IndexedDB` auf einem regulären Web-Ursprung. Diese Prüfung steht in `TESTS.md`. Keine Änderung an `mindfagg-db`, Projekt-ZIPs und VFS.
- Service Worker und Manifest nutzen den Cache-/Paketstand v38.
