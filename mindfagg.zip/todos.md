# Mindfagg

## Mindmap
- Verkleinere den Abstand zwischen den Unterknoten eines Knotens, damit man auf einer Hierachie-Ebene von Unterknoten optisch unterscheiden kann, wann der Elternknoten/Kontext sich ändert.

## App-Einstellungen
- Bei den GitHub-Zugangsdaten den Hinweis platzieren, wie man einen Personal Access Token generiert
    - https://github.com/settings/personal-access-tokens/new
- Wenn ich einen Personal Access Token hinzufüge, fragt mich der Browser, ob ich den Token als Passwort speichern möchte. Versuche, den Browser davon abzuhalten, den Token zum speichern anzubieten.


## GitHub-Repository zuordnen-Dialog
- Sobald ein Repository eingetragen ist, zeigt das Repository als klickbaren Link an, der einen neuen Tab öffnet, um das Repository ggf. zu bearbeiten (github.com/{repo}) oder um es zu erstellen (https://github.com/new).

## HTML, JavaScript, CSS validieren
- Führe Validatoren ein, die HTML, CSS und JS validieren können, um im Script-Editor die fehlerhafte Stelle markieren zu können und um beim Einfügen aus der Zwischenablage reines CSS/JS erkennen zu können.

## Dateien und Ordner hinzufügen
- Füge einen Trennstrich zwischen "Neuer Ordner" und "Dateien hochladen" ein.
- Beim Einfügen von Dateien soll erkannt werden, wenn es sich um CSS oder JavaScript-Dateien handelt.

Gib mir das Ergebnis als v36.


## Mindmap
- Die Abstände zwischen den Unterknoten ist etwas zu klein - Abstand verdoppeln.
- Der Abstand zwischen Blöcken von Knoten (das sind die roten Linien im angehängten Bild) muss etwas größer sein - bspw. 24px - um die Trennung optisch besser zu erkennen.

## Kanban
- Dem "Knoten bearbeiten"-Dialog im Kanbanboard fehlt das Status-Auswahlfeld. Verwende im Kanbanboard den gleichen "Knoten bearbeiten"-Dialog, wie in den anderen Ansichten.

Gib mir das Ergebnis als v37

## Mindmap - Abstände
in state-layout.js positionMapRows(state) die Abstände auf 12 und 24 beschränken:
const siblingGap=depth=>depth===0?24:depth===1?24:depth===2?24:12;

## HTML Vorschau
- Bei einigen meiner Projekte erscheint die Meldung: FEHLER: Uncaught SecurityError: Failed to read the 'localStorage' property from 'Window': The document is sandboxed and lacks the 'allow-same-origin' flag. (Zeile 7890)
- Füge dafür in den App-Einstellungen eine Option ein, um Zugriff auf localStorage und indexeddb zu gewähren (default=off - wie bisher).
- Wenn die Fehlermeldung erscheint, soll darin ein Button platziert sein, mit dem man die Sicherheitsfreigabe sofort erteilen kann.


Gib mir das Ergebnis als v38

## Code Folding
- Cold Folding anbieten für html, css, js, svg, xml, markdown
- Cold Folding als Option (default=on) in den App-Einstellungen hinzufügen

Gib mir nur die geänderten Dateien als v39

## Code Folding
- App-Einstellungen - Code Folding default=off

## GitHub-Repository zuordnen
- Beim Tippen des repositorys den Vorschlag machen, mit dem eigenen Benutzername + / weiter zu machen (bspw. miramax11/)

## Script Editor Tools
- Eine Toolbar für HTML, CSS, JS, XML, SVG einführen, die funktioniert wie im Markdown Editor (auf großen Bildschirmen über der Textarea, auf kleinen Bildschirmen über der Tastatur).
- Vorerst nur eine Funktion: Suchen & Ersetzen
    - Das Dropdown soll sich verhalten, wie in vs code.
    - Standardmäßig zugeklappt: nur Suchen
    - Wechsel zwischen Groß/Klein Schreibung direkt im Suchfeld (wie in vs code).
    - Aufgeklappt: Suchen und Ersetzen
        - Buttons für Ersetzen und Alle Ersetzen
    - Mehrzeilige Texte können gesucht und ersetzt werden
    - kein Regex, kein "Find in Section"

Gib mir nur die geänderten Dateien als v40


## Script Editor Tool: Pretty Code
- Füge in die Toolbar die Funktion "Pretty Code" hinzu.
- Pretty Code ist verfügbar für HTML, JS, CSS, XML, SVG.

## GitHub-Repository zuordnen
- Beim Tippen des repositorys wird aktuell der Vorschlag für ein bereits verwendetes Repository gemacht.
- Verwende als Vorschlagsliste eine Liste der Repositories des Github Users, dem der access token gehört.

Gib mir nur die geänderten Dateien als v41





## Sidebar - Dateiliste
- Ändere das Icon des Collapse Buttons in ein gestrichelt gerahmtes Minus.

### Patch-Tool
- Füge im Dropdown "+" (Dateien und Ordner hinzufügen) einen Patch-Button ein.
- Der Patch-Button öffnet den Dialog des Patch-Tools
- Das Patch-Tool ist in 2 Sektionen geteilt:
    - Einspielen: einen Patch auswählen & einspielen
    - Erstellen: ein Patch wird durch die Erweiterung eines Prompts von einer KI erstellt. Hier steht eine kopierbare Phrase, die man an einen Prompt anhängen kann.
- Patch einfügen
    - JSON Patch einfügen (mit einfügen aus Zwischenablage-Button)
    - Patch per Drag&Drop aus einer .json Datei
    - Patch per Datei-Auswahl beschränkt auf .json
    - Patch Auswahl aus dem Projekt gefiltert auf .patch.json
    - Patches werden nur akzeptiert, wenn sie dem Patch-Format entsprechen.
- Patch Vorschau
    - Zeigt alle Patchvorgänge, standardmäßig sind alle für den Patchvorgang ausgewählt.
- Patch einspielen
    - Der Patch wird entsprechend des Formats angewendet.
    - Die Aktion kann mit einem undo vollständig Rückgängig gemacht werden.

#### Patch-Format
{
  "patches": [
    {
      "file": "index.html",
      "description": "Überschrift aktualisiert",
      "hunks": [
        {
          "search": "    <h1>Alte Überschrift</h1>",
          "replace": "    <h1>Neue Überschrift</h1>",
          "occurrence": 1
        }
      ]
    },
    {
      "file": "app.js",
      "description": "Fehlerbehandlung ergänzt",
      "hunks": [
        {
          "search": "fetch(url).then(r => r.json())",
          "replace": "fetch(url).then(r => {\n  if (!r.ok) throw new Error(r.status);\n  return r.json();\n})",
          "occurrence": 1
        }
      ]
    }
  ]
}

Gib mir das nur die neuen/geänderten Dateien als v44.


{
  "patches": [
    {
      "file": "test.html",
      "description": "Überschrift aktualisiert",
      "hunks": [
        {
          "search": "",
          "replace": "    <h1>Neue Überschrift</h1>",
          "occurrence": 1
        }
      ]
    },
    {
      "file": "test.js",
      "description": "Fehlerbehandlung ergänzt",
      "hunks": [
        {
          "search": "",
          "replace": "fetch(url).then(r => {\n  if (!r.ok) throw new Error(r.status);\n  return r.json();\n})",
          "occurrence": 1
        }
      ]
    }
  ]
}


## Patch-Tool
- Füge die Option "Patch speichern" hinzu, links neben den Button "Ausgewählte Vorgänge einspielen".
    - Ein Patch wird im Projekt-root gespeichert unter "YYYY-MM-DD-HHmmss.patch.json".

## Patch-Format
Erweitere das Patch-Format um Operationen und passe die Patch-Phrase für den KI-Prompt an:
  "patches": [
    {
      "operation": "update",
      "file": "test.html",
      "description": "Überschrift aktualisiert",
      "hunks": [
        {
          "search": "    <h1>Alte Überschrift</h1>",
          "replace": "    <h1>Neue Überschrift</h1>",
          "occurrence": 1
        }
      ]
    },
    {
      "operation": "create",
      "file": "hello.js",
      "content": "const name = 'Welt';"
    },
    {
    "operation": "rename",
    "file": "src/old-name.js",
    "to": "src/new-name.js",
    "description": "Datei umbenennen"
    },
    {
    "operation": "delete",
    "file": "src/test.js",
    "description": "Datei wird nicht mehr gebraucht"
    }
  ]

Operation	Zweck	Felder
create	Datei erstellen	file, content
update	Inhalt ändern	file, hunks
replace	Inhalt komplett ersetzen	file, content
delete	Datei löschen	file
rename	Datei umbenennen/verschieben	file, to


Gib mir die nur die geänderten und neuen Dateien als v45.


## Patch-Tool
- Patch prüfen
    - Entferne den "Patch prüfen"-Button.
    - Färbe den Schriftzug rot und mach ihn klickbar: "Patch prüfen, um die Vorschau zu aktualisieren." - Das ist der kontextsensitive Ersatz für den "Patch prüfen"-Button.
- Mach patch-preview-file zu einem collapsable
    - die Sind standardmäßig zugeklappt
    - Ergänze im head die Infos: operation und patch/ found/ total (Anzahl zu aktualisierender Treffer/ Anzahl der gefundenen Treffer/ Anzahl erwarteter Treffer)

## Dateien teilen
- Den Button "ZIP teilen" umbenennen in "Teilen" mit einem Share-Icon.
- Der Button öffnet einen Dialog, in dem man die Wahl hat, die Dateien als Zip oder einzeln zu senden.
- Darunter kommt eine Liste aller Dateien
    - Zwischenüberschriften mit dem zugehörigen Verzeichnispfad (inklusive root (Wurzel))
    - Checkbox "Alle wählen" je Zwischenüberschrift zum An- und Abwählen einzelnen Verzeichnissen


Gib mir die nur die geänderten und neuen Dateien als v46.


## Dateien teilen
- Füge ein "Alle wählen" über der Dateiliste ein.
- Ergänze die Dateigröße zu den Dateien.
- Zeige eine Summe der gewählten Dateien und der gewählten Gesamtdateigröße unter der Dateiliste.
- Füge einen "Patch-Phrase kopieren" Button links neben dem Abbrechen-Button ein.
    - Der Button kopiert die Patch-Phrase vom Patch-Tool.

## Navigation
- Wenn man den history back button drück, soll ein offener Dialog geschlossen werden.
    - Andernfalls ist history back ein zusätzlicher toggle-Button für die Sidebar

Gib mir die nur die geänderten und neuen Dateien als v47.


## Dateiliste
- Die Buttons "Patch-Tool" und "Teilen" unterhalb des Repository-Buttons nebeneinander platzieren.
- Den Repository-Button nur anzeigen, wenn ein Access Token hinterlegt ist.

### Import/Export Dropdown
- Tooltip Umbenennen in Download
- "ZIP herunterladen" Icon in Zip-Icon (Ordner mit Reißverschluss) ändern.
- "Aktuelle Datei herunterladen" in Datei-Icon ändern .
    - Ersetze den Schriftzug "Originalformat" durch den Namen der aktuellen Datei.

### Dateien und Ordner hinzufügen Dropdown
- "Neue Datei" - Datei-Icon ändern.
- "Neuer Ordner" - Verzeichnis-Icon ändern.
- "ZIP importieren" - Zip-Icon ändern.

Gib mir die nur die geänderten und neuen Dateien als v48.

## Dateiliste
- Tausche die Position der Buttons "Patch-Tool" und "Teilen".

## Patch-Tool
- Wenn man die "Patch abgelehnt"-Meldung anklickt, wird die Fehlermeldung in die Zwischenablage kopiert.

- Ändere die Patch-Phrase
    - Alt: Escape JSON-Zeichen korrekt (insbesondere Anführungszeichen, Backslashes und Zeilenumbrüche als \n).
    - Neu: Escape JSON-Zeichen korrekt (insbesondere Anführungszeichen \", Backslashes \\ und Zeilenumbrüche als \n).

Gib mir die nur die geänderten und neuen Dateien als v49.

## Sidebar - Dateiliste
- Benenne den Button "Patch-Tool" in "Patchen" um.
- Ändere die Symbole für bestimmte Dateitypen:
  - js: gelbes JS-Symbol
  - css: blaues Hash-Symbol
  - htm: oranges <>-Symbol
  - markdown: blauer Pfail nach unten

Gib mir die nur die geänderten und neuen Dateien als v50.

## Markdown Datei - HTML Ansicht
- Eine fünfte Ansicht in der Toolbar: HTML
  - Die HTML-Ansicht stellt das Markdown als HTML dar.
  - Inhaltsverzeichnis
  - Aufgaben, Status, Datum sind wie im Markdown direkt editierbar.

# Toolbar (Ansichten)
- Kanban und Kalender Label werden auf kleinen Bildschirmen ausgeblendet.
- Icons:
  - Mindmap: Verzeichnisstruktur-Icon.
  - Kanban: 3 Senkrechte Striche - wie ein Hamburger-Menü um 90Grad gedreht.
  - Kalender: Kalendy-Smbol.
  - HTML: <>-Symbol.


Gib mir nur die geänderten und neuen Dateien als v51.

## Mermaid mmd
- Unterstützung für mermaid markdown Dateien.
- Diese Dateien verwenden den Script-Editor - wie js, html, css
- Eine Mermaid-Ansicht rendert das mmd.
- Mit Syntax Highlight und Fehleranzeige.

Gib mir nur die geänderten und neuen Dateien als v52.


## Mermaid
- Ändere die Darstellung der Mermaid-Ansicht so, dass man zoomen und sich durch das Bild "ziehen" kann, wie in der Mindmap-Ansicht.
- Entferne die mermaid-preview-toolbar aus der Mermaid-Ansicht.

## Dateien und Ordner hinzufügen
- Wenn man aus der Zwischenablage ein Mermaid-Diagramm einfügt, soll die Dateiendung auf .mmd (mermaid markdown) gesetzt werden.

## Mindmap
- Kürze den node-text in der Darstellung auf 120 Zeichen.

## Markdown-Datei Toolbar
- Verschiebe die Button "HTML" zwischen "Mindmap" und "Kanban".

## Patch-Tool - Patch Vorschau
- Notiere pro Patch die Größenänderung in Byte/KB. Bspw. könnten in 5 Hunks 6KB durch 9KB ersetzt worden sein, das macht +3KB für den Patch.
  - Die Größenänderung wird pro Hunk hinter die (Treffer 1) geschreiben.
  - Die Größenänderung wird pro Patch hinter patch/found/total geschrieben.
  - Die Summe aller Patches wird ans Ende der Dateiliste geschrieben: bspw. +13KB

## Patch-Tool - Patch speichern
- Ändere die Checkbox "Patch speichern" in ein select-Element mit den Optionen:
  - Patch nicht speichern
  - Patch vollständig speichern
  - Patch-Auswahl speichern

Gib mir nur die geänderten und neuen Dateien als v53.

## Mermaid Ansicht
- Platziere unten rechts einen einen Ansicht-Zentrieren-Button mit einem Icon (wie in der Markdown Mindmap-Ansicht).

## Script-Editor
- Führe einen "Pretty Code"-Button für das json-Format ein.

## CSV-Dateien
- Führe CSV als unterstütztes Dateiformat ein.
- Verwende Papa Parse library zur Unterstützung.
- Füge in die App-Einstellungen einen Bereich für neue erstellte CSV-Dateien hinzu:
  - Trennzeichen, Zeichencodierung, Zeilenende, Textbegrenzung.
- Führe ein CSV-Icon für die Dateiliste ein
- Grid-Ansicht 
  - Bei CSV Dateien kommt neben der Script-Ansicht der Button mit der Grid Ansicht hinzu.

Gib mir nur die geänderten und neuen Dateien als v54.

## Patch-Tool Vorschau
- Hebe die Unterschiede der Gegenüberstellung von search und replace hervor.
  - markiere rot, was gestrichen wird.
  - markiere grün, was bleibt.
  - Die Farben müssen wechseln, wenn ein Hunk deaktiviert und wieder aktiviert wird.

Gib mir nur die geänderten und neuen Dateien als v55.

## CSV-Grid
- "+ Zeile" erstellt eine Zeile, über der aktuell ausgewählten Zeile, sonst ganz am Ende
- "+ Spalte" erstellt eine Spalte, links neben der ausgewählten Spalte, sonst ganz am Ende


## Markdown-Datei - HTML-Ansicht
- Entferne das "HTML" Label aus dem Toolbar-Button auf kleinen Bildschirmen.
- add-task-Button, Status-Select und Datum+ entfernen, wenn nicht gesetzt (wird über den Plus-Button geregelt)
- Zu einem Knoten wird ein Plus (+)-Button angezeigt, wenn noch ein Attribut hinzugefügt werden kann.
  - Der Plus-Button öffnet ein Dropdown:
    - Checkbox (Aufgabe)
    - Status
    - Datum
  - Dadurch wirkt ein Knoten aufgeräumter.
- Platziere die Checkbox ohne Label und ohne remove-task-Button links neben den Knoten Namen.


Gib mir nur die geänderten und neuen Dateien als v56.

## Patch-Tool Vorschau
- Ändere die Farbregel im Vergleich von search/replace:
  - wenn Hunk aktiv, dann ist in search rot markiert, was verschwindet und in replace grün, was neu hinzukommt.
  - und umgekehrt, wenn Hunk nicht aktiv.

Gib mir nur die geänderten und neuen Dateien als v57.

## Patch-Tool Vorschau
- Wenn ich einen Hunk deaktiviere, ändert sich der Größenwert hinter search (Treffer 1) nicht (.patch-size-delta).

Gib mir nur die geänderten und neuen Dateien als v58.

## Patch-Tool Vorschau
- Wenn ich einen Hunk bei der operation replace deaktiviere, ändert sich der Größenwert hinter search (Treffer 1) nicht (.patch-size-delta)
- Wenn eine Datei mit replace ersetzt werden soll, zeige dafür auch einen Vergleich.

## HTML-Vorschau Sicherheit
Isoliere die HTML-Vorschau.

Gib mir nur die geänderten und neuen Dateien als v59.

## App-Einstellungen
- Entferne den Abschnit "Neue CSV-Dateien".

## CSV Grid-Ansicht
- Ändere den Button "+ Zeile" in ein Dropdown mit den Optionen "Zeile darüber" und "Zeile darunter".
- Ändere den Button "+ Spalte" in ein Dropdown mit den Optionen "Spalte links" und "Spalte rechts".

Gib mir nur die geänderten und neuen Dateien als v60.

## Markdown HTML-Ansicht
- Der Plus-Dropdown-Button wird erst angezeigt, wenn man auf den zugehörigen Knoten klickt (oder hovert).

Gib mir nur die geänderten und neuen Dateien als v61.

## Markdown HTML-Ansicht
- Der Plus-Dropdown-Button soll das Layout beim hovern nicht verändern. Solange das Element weder Status noch Datum hat, soll der Plus-Dropdown-Button eine absolute Position haben.

Gib mir nur die geänderten und neuen Dateien als v62.

## "Datei teilen"-Dialog
- Ändere das Label des Kopieren-Buttons:
  - "Patch-Phrase kopieren" zu (clipboard-icon) "Patch Phrase"
- Füge den Button (clipboard-icon) "Patch Export" hinzu. Klickt man den Button, werden alle ausgewählten Dateien zu einem Patch mit operation:create in die Zwischenablage kopiert.

Gib mir nur die geänderten und neuen Dateien als v63.

Audit Checkliste:
[ ] P0 HTML-Vorschau sicher isolieren (M)
[ ] P1 Persistenten Speicher und Backup-Hinweise ergänzen (M)
[ ] P1 Mobile ZIP-Grenzen und Speicherschutz verbessern (M)
[ ] P1 Echte iOS-/Android-End-to-End-Tests ergänzen (L)
[ ] P2 Apple-Touch-Icon und Asset-Prüfung korrigieren (S)
[ ] P2 Globale Modulabhängigkeiten reduzieren (L)


- Den Schriftzug "Dein gespeicherter Spielstand wurde wieder hergestellt" als Toast kurz einblenden.
- Die Round-Tabs auf kleinen Bildschirmen ausblenden.
- Entferne die progress-row und verschiebe die progress-rail direkt unter das subheading im game-heading.
- Entferne aus dem meta-stat "Chancen" die Zahlendarstellung (bspw. 2/3) auf kleinen Bildschirmen.
- Verschieben den 50:50 Joker neben den "Chancen"-Button und ändere das Label "Joker einsetzen" in "Joker".

- Entferne die Steuerungsleiste am unteren Bildschirmrand.
- Verschiebe das Scoreboard nach unten.
- Verschiebe den Ton- und Pause-Button übereinander gestapelt links neben den Hold-Button.


## Nur auf kleinen Bildschirmen
- Füge den Button "Neues Spiel" rechts im game-heading ein.
- Blende den site-header aus.
